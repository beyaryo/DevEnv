package com.lynx.wind.dev.dialog

internal interface DialogListener {
    fun onDataChanged(tag: String, data: Any?)
}